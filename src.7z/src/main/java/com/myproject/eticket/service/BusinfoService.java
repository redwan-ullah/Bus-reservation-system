package com.myproject.eticket.service;

import com.myproject.eticket.model.Businfo;
import java.util.List;
import org.springframework.stereotype.Service;

/**
 *
 * @author User
 */
@Service
public interface BusinfoService {
    public Businfo insertBusinfo(Businfo bi);

    public void updateBusinfo(Businfo bi);

    public void deleteBusinfo(Integer id);

    public List<Businfo> viewBusinfo();

    public Businfo viewOneBusinfo(Integer id);
}



