package com.myproject.eticket.service;

import com.myproject.eticket.model.Companyinfo;
import java.util.List;
import org.springframework.stereotype.Service;

/**
 *
 * @author User
 */
@Service
public interface CompanyinfoService {
    public Companyinfo insertCompanyinfo(Companyinfo ci);

    public void updateCompanyinfo(Companyinfo ci);

    public void deleteCompanyinfo(Integer id);

    public List<Companyinfo> viewCompanyinfo();

    public Companyinfo viewOneCompanyinfo(Integer id);
}
