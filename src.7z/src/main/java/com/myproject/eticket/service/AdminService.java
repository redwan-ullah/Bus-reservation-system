package com.myproject.eticket.service;

import com.myproject.eticket.model.Admin;
import java.util.List;
import org.springframework.stereotype.Service;

/**
 *
 * @author User
 */
@Service
public interface AdminService {
    public Admin insertAdmin(Admin bi);

    public void updateAdmin(Admin bi);

    public void deleteAdmin(Integer id);

    public List<Admin> viewAdmin();

    public Admin viewOneAdmin(Integer id);
    public Admin userAuth(String aname, String apass);
     public Admin userName(String aname);
}




