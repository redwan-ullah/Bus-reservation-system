package com.myproject.eticket.service;

import com.myproject.eticket.model.Bustype;
import java.util.List;
import org.springframework.stereotype.Service;

/**
 *
 * @author User
 */
@Service
public interface BustypeService {
    public Bustype insertBustype(Bustype bty);

    public void updateBustype(Bustype bty);

    public void deleteBustype(Integer id);

    public List<Bustype> viewBustype();

    public Bustype viewOneBustype(Integer id);
}

