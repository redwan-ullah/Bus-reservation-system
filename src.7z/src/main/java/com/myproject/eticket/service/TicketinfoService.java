package com.myproject.eticket.service;

import com.myproject.eticket.model.Ticketinfo;
import java.util.List;
import org.springframework.stereotype.Service;

/**
 *
 * @author User
 */
@Service
public interface TicketinfoService {
    public Ticketinfo insertTicketinfo(Ticketinfo ti);

    public void updateTicketinfo(Ticketinfo ti);

    public void deleteTicketinfo(Integer id);

    public List<Ticketinfo> viewTicketinfo();

    public Ticketinfo viewOneTicketinfo(Integer id);
}

