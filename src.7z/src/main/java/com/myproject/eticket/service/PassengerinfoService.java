package com.myproject.eticket.service;

import com.myproject.eticket.model.Passengerinfo;
import java.util.List;
import org.springframework.stereotype.Service;

/**
 *
 * @author User
 */
@Service
public interface PassengerinfoService {
    public Passengerinfo insertPassengerinfo(Passengerinfo pi);

    public void updatePassengerinfo(Passengerinfo pi);

    public void deletePassengerinfo(Integer id);

    public List<Passengerinfo> viewPassengerinfo();

    public Passengerinfo viewOnePassengerinfo(Integer id);
}
