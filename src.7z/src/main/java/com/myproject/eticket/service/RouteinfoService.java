package com.myproject.eticket.service;

import com.myproject.eticket.model.Rinfo;
import com.myproject.eticket.model.Routeinfo;
import java.util.List;
import org.springframework.stereotype.Service;

/**
 *
 * @author User
 */
@Service
public interface RouteinfoService {
    public Routeinfo insertRouteinfo(Routeinfo ri);

    public void updateRouteinfo(Routeinfo ri);

    public void deleteRouteinfo(Integer id);

    public List<Routeinfo> viewRouteinfo();

    public Routeinfo viewOneRouteinfo(Integer id);
    
     public Routeinfo viewOneSpecRouteinfo(String sor, String des,String type);
     
      public Routeinfo viewOneSpecRouteinfoViceVersa(String sor, String des,String type);
      
      
}

