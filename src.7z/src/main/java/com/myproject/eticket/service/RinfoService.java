package com.myproject.eticket.service;

import com.myproject.eticket.model.Rinfo;
import java.util.List;
import org.springframework.stereotype.Service;

/**
 *
 * @author User
 */
@Service
public interface RinfoService {
    public Rinfo insertRinfo(Rinfo bi);

    public void updateRinfo(Rinfo bi);

    public void deleteRinfo(Integer id);

    public List<Rinfo> viewRinfo();

    public Rinfo viewOneRinfo(Integer id);
    public List<Rinfo> viewOneSpecRinfo(String sor,String des,String ddate);
    
    public List<String> viewSourceInfo();
    
    public List<String> getDestination(String sor);
    
    public void updateSeats(String ddate,String ndate);
 
}






