package com.myproject.eticket.service;

import com.myproject.eticket.model.Seatinfo;
import java.util.List;
import org.springframework.stereotype.Service;

/**
 *
 * @author User
 */
@Service
public interface SeatinfoService {
    public Seatinfo insertSeatinfo(Seatinfo si);

    public void updateSeatinfo(Seatinfo si);

    public void deleteSeatinfo(Integer id);

    public List<Seatinfo> viewSeatinfo();

    public Seatinfo viewOneSeatinfo(Integer id);
}

