/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.myproject.eticket.service;


import com.myproject.eticket.model.Bustimetable;
import java.util.List;
import org.springframework.stereotype.Service;

/**
 *
 * @author User
 */
@Service
public interface BustimetableService {
    public Bustimetable insertBustimetable(Bustimetable bt);

    public void updateBustimetable(Bustimetable bt);

    public void deleteBustimetable(Integer id);

    public List<Bustimetable> viewBustimetable();

    public Bustimetable viewOneBustimetable(Integer id);
}
