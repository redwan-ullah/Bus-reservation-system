package com.myproject.eticket.service;

import com.myproject.eticket.model.Finalticket;
import java.util.List;
import org.springframework.stereotype.Service;

/**
 *
 * @author User
 */
@Service
public interface FinalticketService {
    public Finalticket insertFinalticket(Finalticket bi);

    public void updateFinalticket(Finalticket bi);

    public void deleteFinalticket(Integer id);

    public List<Finalticket> viewFinalticket();

    public Finalticket viewOneFinalticket(Integer id);
    
    public Finalticket viewOneByTicketNum(Integer ticketnumber);
    
 
}



