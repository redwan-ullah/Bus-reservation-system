/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.myproject.eticket.repository;

import com.myproject.eticket.model.Ticketinfo;
import com.myproject.eticket.service.TicketinfoService;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author User
 */
@Repository
public class TicketinfoRepository implements TicketinfoService{

    @Autowired
    SessionFactory sessionFactory;
    @Override
    public Ticketinfo insertTicketinfo(Ticketinfo ti) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        s.save(ti);
        t.commit();
        s.close();
        return ti;
    }

    @Override
    public void updateTicketinfo(Ticketinfo ti) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        //CategoriesModel cm = (CategoriesModel)s.get(CategoriesModel.class, categoryid);
        s.update(ti);
        t.commit();
        s.close();
    }

    @Override
    public void deleteTicketinfo(Integer id) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Ticketinfo ti = (Ticketinfo) s.get(Ticketinfo.class, id);
        s.delete(ti);
        t.commit();
        s.close();
    }

    @Override
    public List<Ticketinfo> viewTicketinfo() {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        List<Ticketinfo> businfolist = s.createQuery("from Ticketinfo").list();
        t.commit();
        s.close();
        //System.out.println(categorylistgson);
        return businfolist;
    }

    @Override
    public Ticketinfo viewOneTicketinfo(Integer id) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Ticketinfo ti = (Ticketinfo) s.get(Ticketinfo.class, id);
        t.commit();
        s.close();
        return ti;
    }

   
    
}



