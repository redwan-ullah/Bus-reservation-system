/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.myproject.eticket.repository;

import com.myproject.eticket.model.Passengerinfo;
import com.myproject.eticket.service.PassengerinfoService;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author User
 */
@Repository
public class PassengerinfoRepository implements PassengerinfoService{

    @Autowired
    SessionFactory sessionFactory;
    @Override
    public Passengerinfo insertPassengerinfo(Passengerinfo pi) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        s.save(pi);
        t.commit();
        s.close();
        return pi;
    }

    @Override
    public void updatePassengerinfo(Passengerinfo pi) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        //CategoriesModel cm = (CategoriesModel)s.get(CategoriesModel.class, categoryid);
        s.update(pi);
        t.commit();
        s.close();
    }

    @Override
    public void deletePassengerinfo(Integer id) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Passengerinfo pi = (Passengerinfo) s.get(Passengerinfo.class, id);
        s.delete(pi);
        t.commit();
        s.close();
    }

    @Override
    public List<Passengerinfo> viewPassengerinfo() {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        List<Passengerinfo> businfolist = s.createQuery("from Passengerinfo").list();
        t.commit();
        s.close();
        //System.out.println(categorylistgson);
        return businfolist;
    }

    @Override
    public Passengerinfo viewOnePassengerinfo(Integer id) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Passengerinfo pi = (Passengerinfo) s.get(Passengerinfo.class, id);
        t.commit();
        s.close();
        return pi;
    }

   
    
}



