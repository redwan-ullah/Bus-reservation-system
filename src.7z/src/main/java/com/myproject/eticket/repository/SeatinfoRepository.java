/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.myproject.eticket.repository;

import com.myproject.eticket.model.Seatinfo;
import com.myproject.eticket.service.SeatinfoService;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author User
 */
@Repository
public class SeatinfoRepository implements SeatinfoService{

    @Autowired
    SessionFactory sessionFactory;
    @Override
    public Seatinfo insertSeatinfo(Seatinfo si) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        s.save(si);
        t.commit();
        s.close();
        return si;
    }

    @Override
    public void updateSeatinfo(Seatinfo si) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        //CategoriesModel cm = (CategoriesModel)s.get(CategoriesModel.class, categoryid);
        s.update(si);
        t.commit();
        s.close();
    }

    @Override
    public void deleteSeatinfo(Integer id) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Seatinfo si = (Seatinfo) s.get(Seatinfo.class, id);
        s.delete(si);
        t.commit();
        s.close();
    }

    @Override
    public List<Seatinfo> viewSeatinfo() {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        List<Seatinfo> businfolist = s.createQuery("from Seatinfo").list();
        t.commit();
        s.close();
        //System.out.println(categorylistgson);
        return businfolist;
    }

    @Override
    public Seatinfo viewOneSeatinfo(Integer id) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Seatinfo si = (Seatinfo) s.get(Seatinfo.class, id);
        t.commit();
        s.close();
        return si;
    }

   
    
}



