/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.myproject.eticket.repository;

import com.myproject.eticket.model.Bustype;
import com.myproject.eticket.service.BustypeService;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author User
 */
@Repository
public class BustypeRepository implements BustypeService{

    @Autowired
    SessionFactory sessionFactory;
    @Override
    public Bustype insertBustype(Bustype bty) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        s.save(bty);
        t.commit();
        s.close();
        return bty;
    }

    @Override
    public void updateBustype(Bustype bty) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        //CategoriesModel cm = (CategoriesModel)s.get(CategoriesModel.class, categoryid);
        s.update(bty);
        t.commit();
        s.close();
    }

    @Override
    public void deleteBustype(Integer id) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Bustype bty = (Bustype) s.get(Bustype.class, id);
        s.delete(bty);
        t.commit();
        s.close();
    }

    @Override
    public List<Bustype> viewBustype() {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        List<Bustype> businfolist = s.createQuery("from Bustype").list();
        t.commit();
        s.close();
        //System.out.println(categorylistgson);
        return businfolist;
    }

    @Override
    public Bustype viewOneBustype(Integer id) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Bustype bty = (Bustype) s.get(Bustype.class, id);
        t.commit();
        s.close();
        return bty;
    }

   
    
}



