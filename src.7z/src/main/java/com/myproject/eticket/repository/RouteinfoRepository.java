/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.myproject.eticket.repository;

import com.myproject.eticket.model.Routeinfo;
import com.myproject.eticket.service.RouteinfoService;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author User
 */
@Repository
public class RouteinfoRepository implements RouteinfoService{

    @Autowired
    SessionFactory sessionFactory;
    @Override
    public Routeinfo insertRouteinfo(Routeinfo ri) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        s.save(ri);
        t.commit();
        s.close();
        return ri;
    }

    @Override
    public void updateRouteinfo(Routeinfo ri) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        //CategoriesModel cm = (CategoriesModel)s.get(CategoriesModel.class, categoryid);
        s.update(ri);
        t.commit();
        s.close();
    }

    @Override
    public void deleteRouteinfo(Integer id) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Routeinfo ri = (Routeinfo) s.get(Routeinfo.class, id);
        s.delete(ri);
        t.commit();
        s.close();
    }

    @Override
    public List<Routeinfo> viewRouteinfo() {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        List<Routeinfo> businfolist = s.createQuery("from Routeinfo").list();
        t.commit();
        s.close();
        //System.out.println(categorylistgson);
        return businfolist;
    }

    @Override
    public Routeinfo viewOneRouteinfo(Integer id) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Routeinfo ri = (Routeinfo) s.get(Routeinfo.class, id);
        t.commit();
        s.close();
        return ri;
    }



   

       @Override
    public Routeinfo viewOneSpecRouteinfo(String sor, String des,String type) {
         Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();        
        Query query = s.createQuery("from Routeinfo r where r.source = :sor  and r.destination= :des  and r.btype= :btyp");
        query.setParameter("sor", sor);
        query.setParameter("des", des);
        query.setParameter("btyp", type);
        Routeinfo rf = (Routeinfo) query.uniqueResult();
        t.commit();
        s.close();
        return rf;
    }

    @Override
    public Routeinfo viewOneSpecRouteinfoViceVersa(String sor, String des,String type) {
         Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();        
        Query query = s.createQuery("from Routeinfo r where r.source = :sor  and r.destination= :des  and r.btype= :btyp");
        query.setParameter("sor", des);
        query.setParameter("des", sor);
        query.setParameter("btyp", type);
        Routeinfo rf = (Routeinfo) query.uniqueResult();
        t.commit();
        s.close();
        return rf;
    }

   
   
    
}



