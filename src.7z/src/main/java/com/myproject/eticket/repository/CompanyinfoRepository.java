/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.myproject.eticket.repository;

import com.myproject.eticket.model.Companyinfo;
import com.myproject.eticket.service.CompanyinfoService;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author User
 */
@Repository
public class CompanyinfoRepository implements CompanyinfoService{

    @Autowired
    SessionFactory sessionFactory;
    @Override
    public Companyinfo insertCompanyinfo(Companyinfo ci) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        s.save(ci);
        t.commit();
        s.close();
        return ci;
    }

    @Override
    public void updateCompanyinfo(Companyinfo ci) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        //CategoriesModel cm = (CategoriesModel)s.get(CategoriesModel.class, categoryid);
        s.update(ci);
        t.commit();
        s.close();
    }

    @Override
    public void deleteCompanyinfo(Integer id) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Companyinfo ci = (Companyinfo) s.get(Companyinfo.class, id);
        s.delete(ci);
        t.commit();
        s.close();
    }

    @Override
    public List<Companyinfo> viewCompanyinfo() {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        List<Companyinfo> businfolist = s.createQuery("from Companyinfo").list();
        t.commit();
        s.close();
        //System.out.println(categorylistgson);
        return businfolist;
    }

    @Override
    public Companyinfo viewOneCompanyinfo(Integer id) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Companyinfo ci = (Companyinfo) s.get(Companyinfo.class, id);
        t.commit();
        s.close();
        return ci;
    }

   
    
}



