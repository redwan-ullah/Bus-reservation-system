/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.myproject.eticket.repository;

import com.myproject.eticket.model.Admin;
import com.myproject.eticket.model.Routeinfo;
import com.myproject.eticket.service.AdminService;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author User
 */
@Repository
public class AdminRepository implements AdminService{

    @Autowired
    SessionFactory sessionFactory;
    @Override
    public Admin insertAdmin(Admin bi) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        s.save(bi);
        t.commit();
        s.close();
        return bi;
    }

    @Override
    public void updateAdmin(Admin bi) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        //CategoriesModel cm = (CategoriesModel)s.get(CategoriesModel.class, categoryid);
        s.update(bi);
        t.commit();
        s.close();
    }

    @Override
    public void deleteAdmin(Integer id) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Admin bi = (Admin) s.get(Admin.class, id);
        s.delete(bi);
        t.commit();
        s.close();
    }

    @Override
    public List<Admin> viewAdmin() {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        List<Admin> businfolist = s.createQuery("from Admin").list();
        t.commit();
        s.close();
        //System.out.println(categorylistgson);
        return businfolist;
    }

    @Override
    public Admin viewOneAdmin(Integer id) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Admin bi = (Admin) s.get(Admin.class, id);
        t.commit();
        s.close();
        return bi;
    }

        @Override
    public Admin userAuth(String aname, String apass) {
         Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();        
        Query query = s.createQuery("from Admin a where a.adname = :sor  and a.adpassword= :des ");
        query.setParameter("sor", aname);
        query.setParameter("des", apass);
        Admin rf = (Admin) query.uniqueResult();
        t.commit();
        s.close();
        return rf;
    }

            @Override
    public Admin userName(String aname) {
         Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();        
        Query query = s.createQuery("from Admin a where a.adname = :sor  ");
        query.setParameter("sor", aname);
        Admin rf = (Admin) query.uniqueResult();
        t.commit();
        s.close();
        return rf;
    }

    
}

