/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.myproject.eticket.repository;

import com.myproject.eticket.model.Finalticket;
import com.myproject.eticket.model.Routeinfo;
import com.myproject.eticket.service.FinalticketService;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author User
 */
@Repository
public class FinalticketRepository implements FinalticketService{

    @Autowired
    SessionFactory sessionFactory;
    @Override
    public Finalticket insertFinalticket(Finalticket bi) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        s.save(bi);
        t.commit();
        s.close();
        return bi;
    }

    @Override
    public void updateFinalticket(Finalticket bi) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        //CategoriesModel cm = (CategoriesModel)s.get(CategoriesModel.class, categoryid);
        s.update(bi);
        t.commit();
        s.close();
    }

    @Override
    public void deleteFinalticket(Integer id) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Finalticket bi = (Finalticket) s.get(Finalticket.class, id);
        s.delete(bi);
        t.commit();
        s.close();
    }

    @Override
    public List<Finalticket> viewFinalticket() {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        List<Finalticket> businfolist = s.createQuery("from Finalticket").list();
        t.commit();
        s.close();
        //System.out.println(categorylistgson);
        return businfolist;
    }

    @Override
    public Finalticket viewOneFinalticket(Integer id) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Finalticket bi = (Finalticket) s.get(Finalticket.class, id);
        t.commit();
        s.close();
        return bi;
    }
 @Override
    public Finalticket viewOneByTicketNum(Integer ticketnumber) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();        
        Query query = s.createQuery("from Finalticket f where f.ticketnumber = :sor  ");
        query.setParameter("sor", ticketnumber);
        Finalticket ft = (Finalticket) query.uniqueResult();
        t.commit();
        s.close();
        return ft;
    }
//    @Override
//   public void deletebyId(Integer id){
//   
//         Session s = sessionFactory.openSession();
//        Transaction t = s.getTransaction();
//        t.begin();        
//        Query query = s.createQuery("delete from Finalticket f where f.tid = :sor  ");
//        query.setParameter("sor", id);
//        int i=query.executeUpdate();
//        t.commit();
//        s.close();
//       
//   
//   
//   }
   
    
}

