/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.myproject.eticket.repository;

import com.myproject.eticket.model.Rinfo;
import com.myproject.eticket.service.RinfoService;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author User
 */
@Repository
public class RinfoRepository implements RinfoService{

    @Autowired
    SessionFactory sessionFactory;
    @Override
    public Rinfo insertRinfo(Rinfo bi) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        s.save(bi);
        t.commit();
        s.close();
        return bi;
    }

    @Override
    public void updateRinfo(Rinfo bi) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        //CategoriesModel cm = (CategoriesModel)s.get(CategoriesModel.class, categoryid);
        s.update(bi);
        t.commit();
        s.close();
    }

    @Override
    public void deleteRinfo(Integer id) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Rinfo bi = (Rinfo) s.get(Rinfo.class, id);
        s.delete(bi);
        t.commit();
        s.close();
    }

    @Override
    public List<Rinfo> viewRinfo() {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        List<Rinfo> businfolist = s.createQuery("from Rinfo").list();
        t.commit();
        s.close();
        //System.out.println(categorylistgson);
        return businfolist;
    }

    @Override
    public Rinfo viewOneRinfo(Integer id) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Rinfo bi = (Rinfo) s.get(Rinfo.class, id);
        t.commit();
        s.close();
        return bi;
    }

    @Override
    public List<Rinfo> viewOneSpecRinfo(String sor, String des,String ddate) {
         Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Query query = s.createQuery("from Rinfo r where r.source = :sor and r.destination= :des and r.ddate= :ddate and r.seatnum >=1");
        query.setParameter("sor", sor);
        query.setParameter("des", des);
        query.setParameter("ddate", ddate);
        List<Rinfo> rf = (List<Rinfo>)query.list();
        t.commit();
        s.close();
        return rf;
    }
   @Override
    public List<String> viewSourceInfo() {
       Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        List<String> businfolist = s.createQuery("select distinct source from Rinfo").list();
        t.commit();
        s.close();
        return businfolist;  
    }

    @Override
    public List<String> getDestination(String sor) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Query query = s.createQuery("select distinct destination from Rinfo r where r.           source = :sor");
        query.setParameter("sor", sor);      
        List<String> rf = (List<String>)query.list();
        t.commit();
        s.close();
        return rf;
    }

    @Override
    public void updateSeats(String ddate,String ndate) {
       Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();        
        Query query = s.createQuery("update Rinfo r set r.a1=1 , r.a2=1,r.a3=1 , r.a4=1,r.b1=1 , r.b2=1,r.b3=1 , r.b4=1,r.c1=1 , r.c2=1,r.c3=1 , r.c4=1,r.d1=1 , r.d2=1,r.d3=1 , r.d4=1,r.e1=1 , r.e2=1,r.e3=1 , r.e4=1,r.f1=1 , r.f2=1,r.f3=1 , r.f4=1,r.g1=1 , r.g2=1,r.g3=1 , r.g4=1,r.h1=1 , r.h2=1,r.h3=1 , r.h4=1,r.i1=1 , r.i2=1,r.i3=1 , r.i4=1,r.j1=1 , r.j2=1,r.j3=1 , r.j4=1 where r.ddate = :sor  ");
        query.setParameter("sor", ddate);
        int i=query.executeUpdate();
         Query que = s.createQuery("update Rinfo r set seatnum = 30  where r.ddate = :ddate and r.bustype='AC' ");
        que.setParameter("ddate", ddate);
        int k=que.executeUpdate();
        Query qu = s.createQuery("update Rinfo r set seatnum = 40  where r.ddate = :kor and r.bustype='Non AC' ");
        qu.setParameter("kor", ddate);
        int j=qu.executeUpdate();
        
         Query nqu = s.createQuery("update Rinfo r set r.ddate=:ndate  where r.ddate=:odate");
         nqu.setParameter("ndate", ndate);
        nqu.setParameter("odate", ddate);
        int l=nqu.executeUpdate();
         
        
        t.commit();
        s.close();
   
    
}


}

