/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.myproject.eticket.repository;

import com.myproject.eticket.model.Businfo;
import com.myproject.eticket.service.BusinfoService;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author User
 */
@Repository
public class BusinfoRepository implements BusinfoService{

    @Autowired
    SessionFactory sessionFactory;
    @Override
    public Businfo insertBusinfo(Businfo bi) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        s.save(bi);
        t.commit();
        s.close();
        return bi;
    }

    @Override
    public void updateBusinfo(Businfo bi) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        //CategoriesModel cm = (CategoriesModel)s.get(CategoriesModel.class, categoryid);
        s.update(bi);
        t.commit();
        s.close();
    }

    @Override
    public void deleteBusinfo(Integer id) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Businfo bi = (Businfo) s.get(Businfo.class, id);
        s.delete(bi);
        t.commit();
        s.close();
    }

    @Override
    public List<Businfo> viewBusinfo() {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        List<Businfo> businfolist = s.createQuery("from Businfo").list();
        t.commit();
        s.close();
        //System.out.println(categorylistgson);
        return businfolist;
    }

    @Override
    public Businfo viewOneBusinfo(Integer id) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Businfo bi = (Businfo) s.get(Businfo.class, id);
        t.commit();
        s.close();
        return bi;
    }

   
    
}

