/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.myproject.eticket.controller;

import com.myproject.eticket.model.Bustype;
import com.myproject.eticket.service.BustypeService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author User
 */
@RestController
@RequestMapping(value = "/api/v1")
public class BustypeController {

    @Autowired
    private BustypeService bustypeService;

    @GetMapping("/bustype")
    public List<Bustype> getAllBustype() {
        return bustypeService.viewBustype();
    }

    @PostMapping("/bustype")
    public Bustype createBustype(@RequestBody Bustype bustype) {
        return bustypeService.insertBustype(bustype);
    }

    @GetMapping("/bustype/{id}")
    public ResponseEntity<Bustype> getBustype(@PathVariable("id") Integer id) {
        System.out.println("Fetching User with id " + id);
        Bustype bustype = bustypeService.viewOneBustype(id);
        if (bustype == null) {
            System.out.println("Bustype with id " + id + " not found");
            return new ResponseEntity<Bustype>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Bustype>(bustype, HttpStatus.OK);
    }

    @PutMapping("/bustype/{id}")
    public ResponseEntity<Bustype> updateBustype(@PathVariable("id") Integer id, @RequestBody Bustype bustype) {
        System.out.println("Updating Bustype " + id);

        Bustype currentBustype = bustypeService.viewOneBustype(id);

        if (currentBustype == null) {
            System.out.println("Bustype with id " + id + " not found");
            return new ResponseEntity<Bustype>(HttpStatus.NOT_FOUND);
        }

        currentBustype.setTypeid(bustype.getTypeid());
        currentBustype.setType(bustype.getType());
        
        

        bustypeService.updateBustype(currentBustype);
        return new ResponseEntity<Bustype>(currentBustype, HttpStatus.OK);
    }

    @DeleteMapping("/bustype/{id}")
    public ResponseEntity<Bustype> deleteBustype(@PathVariable("id") Integer id) {
        System.out.println("Fetching & Deleting Bustype with id " + id);

        Bustype bustype = bustypeService.viewOneBustype(id);
        if (bustype == null) {
            System.out.println("Unable to delete. Bustype with id " + id + " not found");
            return new ResponseEntity<Bustype>(HttpStatus.NOT_FOUND);
        }

        bustypeService.deleteBustype(id);
        return new ResponseEntity<Bustype>(HttpStatus.NO_CONTENT);
    }

}
