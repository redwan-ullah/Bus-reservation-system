/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.myproject.eticket.controller;

import com.myproject.eticket.model.Rinfo;
import com.myproject.eticket.service.RinfoService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author User
 */
@RestController
@RequestMapping(value = "/api/v1")
public class RinfoController {

    @Autowired
    private RinfoService rinfoService;

    @GetMapping("/rinfo")
    public List<Rinfo> getAllRinfo() {
        return rinfoService.viewRinfo();
    }
      @GetMapping("/rinfo/source")
    public List<String> getoneRouteinfo() {
        return rinfoService.viewSourceInfo();
    }

    @PostMapping("/rinfo")
    public Rinfo createRinfo(@RequestBody Rinfo rinfo) {
        return rinfoService.insertRinfo(rinfo);
    }

    @GetMapping("/rinfo/des/{source}")
    public List<String> getDestination(@PathVariable("source") String source) {
        System.out.println("Fetching User with id " + source);
        List rinfo = rinfoService.getDestination(source);
        
        return rinfo;
    }
    
     @GetMapping("/rinfo/{id}")
    public ResponseEntity<Rinfo> getRinfo(@PathVariable("id") Integer id) {
        System.out.println("Fetching User with id " + id);
        Rinfo rinfo = rinfoService.viewOneRinfo(id);
        if (rinfo == null) {
            System.out.println("Rinfo with id " + id + " not found");
           
        }
        return new ResponseEntity<Rinfo>(rinfo, HttpStatus.OK);
    }
    
     @GetMapping("/rinfo/sds/{source}/{destination}/{ddate}")
    public List<Rinfo> getallRinfo(@PathVariable("source") String source,@PathVariable("destination") String destination,@PathVariable("ddate") String ddate) {
        System.out.println("Fetching User with id " + source);
        List<Rinfo> rinfo = rinfoService.viewOneSpecRinfo(source,destination,ddate);
        if (rinfo == null) {
            System.out.println("Rinfo with id " + source + " not found");
             
        }
        return rinfo;
    }
//updateDate(String ddate)
    @PutMapping("/rinfo/{id}")
    public ResponseEntity<Rinfo> updateRinfoSeat(@PathVariable("id") Integer id, @RequestBody Rinfo rinfo) {
        System.out.println("Updating Rinfo " + id);

        Rinfo currentRinfo = rinfoService.viewOneRinfo(id);

        if (currentRinfo == null) {
            System.out.println("Rinfo with id " + id + " not found");
            return new ResponseEntity<Rinfo>(HttpStatus.NOT_FOUND);
        }

        currentRinfo.setRid(rinfo.getRid());
        currentRinfo.setSource(rinfo.getSource());
        currentRinfo.setDestination(rinfo.getDestination());
        currentRinfo.setDdate(rinfo.getDdate());
        currentRinfo.setDtime(rinfo.getDtime());
        currentRinfo.setSeatnum(rinfo.getSeatnum());
        currentRinfo.setA1(rinfo.getA1());
        currentRinfo.setA2(rinfo.getA2());
        currentRinfo.setA3(rinfo.getA3());
        currentRinfo.setA4(rinfo.getA4());
        currentRinfo.setB1(rinfo.getB1());
        currentRinfo.setB2(rinfo.getB2());
        currentRinfo.setB3(rinfo.getB3());
        currentRinfo.setB4(rinfo.getB4());
        currentRinfo.setC1(rinfo.getC1());
        currentRinfo.setC2(rinfo.getC2());
        currentRinfo.setC3(rinfo.getC3());
        currentRinfo.setC4(rinfo.getC4());
        currentRinfo.setD1(rinfo.getD1());
        currentRinfo.setD2(rinfo.getD2());
        currentRinfo.setD3(rinfo.getD3());
        currentRinfo.setD4(rinfo.getD4());
         currentRinfo.setE1(rinfo.getE1());
        currentRinfo.setE2(rinfo.getE2());
         currentRinfo.setE3(rinfo.getE3());
        currentRinfo.setE4(rinfo.getE4());
        currentRinfo.setF1(rinfo.getF1());
        currentRinfo.setF2(rinfo.getF2());
        currentRinfo.setF3(rinfo.getF3());
        currentRinfo.setF4(rinfo.getF4());
        currentRinfo.setG1(rinfo.getG1());
        currentRinfo.setG2(rinfo.getG2());
        currentRinfo.setG3(rinfo.getG3());
        currentRinfo.setG4(rinfo.getG4());
        currentRinfo.setH1(rinfo.getH1());
        currentRinfo.setH2(rinfo.getH2());
        currentRinfo.setH3(rinfo.getH3());
        currentRinfo.setH4(rinfo.getH4());
        currentRinfo.setI1(rinfo.getI1());
        currentRinfo.setI2(rinfo.getI2());
        currentRinfo.setI3(rinfo.getI3());
        currentRinfo.setI4(rinfo.getI4());
        currentRinfo.setJ1(rinfo.getJ1());
        currentRinfo.setJ2(rinfo.getJ2());
        currentRinfo.setJ3(rinfo.getJ3());
        currentRinfo.setJ4(rinfo.getJ4());
        currentRinfo.setBustype(rinfo.getBustype());
        currentRinfo.setRouteid(rinfo.getRouteid());
        

        rinfoService.updateRinfo(currentRinfo);
        return new ResponseEntity<Rinfo>(currentRinfo, HttpStatus.OK);
    }

    @DeleteMapping("/rinfo/{id}")
    public ResponseEntity<Rinfo> deleteRinfo(@PathVariable("id") Integer id) {
        System.out.println("Fetching & Deleting Rinfo with id " + id);

        Rinfo rinfo = rinfoService.viewOneRinfo(id);
        if (rinfo == null) {
            System.out.println("Unable to delete. Rinfo with id " + id + " not found");
            return new ResponseEntity<Rinfo>(HttpStatus.NOT_FOUND);
        }

        rinfoService.deleteRinfo(id);
        return new ResponseEntity<Rinfo>(HttpStatus.NO_CONTENT);
    }


      @PutMapping("/rinfo/ddate/{ddate}/{ndate}")
    public void updateSeats(@PathVariable("ddate") String ddate,@PathVariable("ndate") String ndate) {
                 rinfoService.updateSeats(ddate,ndate);
    } 
}
