/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.myproject.eticket.controller;

import com.myproject.eticket.model.Companyinfo;
import com.myproject.eticket.service.CompanyinfoService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author User
 */
@RestController
@RequestMapping(value = "/api/v1")
public class CompanyinfoController {

    @Autowired
    private CompanyinfoService companyinfoService;

    @GetMapping("/companyinfo")
    public List<Companyinfo> getAllCompanyinfo() {
        return companyinfoService.viewCompanyinfo();
    }

    @PostMapping("/companyinfo")
    public Companyinfo createCompanyinfo(@RequestBody Companyinfo companyinfo) {
        return companyinfoService.insertCompanyinfo(companyinfo);
    }

    @GetMapping("/companyinfo/{id}")
    public ResponseEntity<Companyinfo> getCompanyinfo(@PathVariable("id") Integer id) {
        System.out.println("Fetching User with id " + id);
        Companyinfo companyinfo = companyinfoService.viewOneCompanyinfo(id);
        if (companyinfo == null) {
            System.out.println("Companyinfo with id " + id + " not found");
            return new ResponseEntity<Companyinfo>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Companyinfo>(companyinfo, HttpStatus.OK);
    }

    @PutMapping("/companyinfo/{id}")
    public ResponseEntity<Companyinfo> updateCompanyinfo(@PathVariable("id") Integer id, @RequestBody Companyinfo companyinfo) {
        System.out.println("Updating Companyinfo " + id);

        Companyinfo currentCompanyinfo = companyinfoService.viewOneCompanyinfo(id);

        if (currentCompanyinfo == null) {
            System.out.println("Companyinfo with id " + id + " not found");
            return new ResponseEntity<Companyinfo>(HttpStatus.NOT_FOUND);
        }

        currentCompanyinfo.setAddress(companyinfo.getAddress());
        currentCompanyinfo.setCompanyname(companyinfo.getCompanyname());
        currentCompanyinfo.setCompanyid(companyinfo.getCompanyid());
        currentCompanyinfo.setContact(companyinfo.getContact());
        

        companyinfoService.updateCompanyinfo(currentCompanyinfo);
        return new ResponseEntity<Companyinfo>(currentCompanyinfo, HttpStatus.OK);
    }

    @DeleteMapping("/companyinfo/{id}")
    public ResponseEntity<Companyinfo> deleteCompanyinfo(@PathVariable("id") Integer id) {
        System.out.println("Fetching & Deleting Companyinfo with id " + id);

        Companyinfo companyinfo = companyinfoService.viewOneCompanyinfo(id);
        if (companyinfo == null) {
            System.out.println("Unable to delete. Companyinfo with id " + id + " not found");
            return new ResponseEntity<Companyinfo>(HttpStatus.NOT_FOUND);
        }

        companyinfoService.deleteCompanyinfo(id);
        return new ResponseEntity<Companyinfo>(HttpStatus.NO_CONTENT);
    }

}

