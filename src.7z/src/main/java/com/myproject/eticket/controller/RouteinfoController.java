/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.myproject.eticket.controller;

import com.myproject.eticket.model.Routeinfo;
import com.myproject.eticket.service.RouteinfoService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author User
 */
@RestController
@RequestMapping(value = "/api/v1")
public class RouteinfoController {

    @Autowired
    private RouteinfoService routeinfoService;

    @GetMapping("/routeinfo")
    public List<Routeinfo> getAllRouteinfo() {
        return routeinfoService.viewRouteinfo();
    }

    
    @PostMapping("/routeinfo")
    public Routeinfo createRouteinfo(@RequestBody Routeinfo routeinfo) {
        return routeinfoService.insertRouteinfo(routeinfo);
    }

    @GetMapping("/routeinfo/{id}")
    public ResponseEntity<Routeinfo> getRouteinfo(@PathVariable("id") Integer id) {
        System.out.println("Fetching User with id " + id);
        Routeinfo routeinfo = routeinfoService.viewOneRouteinfo(id);
        if (routeinfo == null) {
            System.out.println("Routeinfo with id " + id + " not found");
            return new ResponseEntity<Routeinfo>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Routeinfo>(routeinfo, HttpStatus.OK);
    }
    
       @GetMapping("/routeinfo/sdb/{source}/{destination}/{btype}")
    public ResponseEntity<Integer> getOneSpecRouteinfo(@PathVariable("source") String source,@PathVariable("destination") String destination,@PathVariable("btype") String btype) {
        System.out.println("Fetching User with id " + source);
        Routeinfo routeinfo = routeinfoService.viewOneSpecRouteinfo(source,destination,btype);
        if (routeinfo == null) {
            Routeinfo routeinfoVc = routeinfoService.viewOneSpecRouteinfoViceVersa(source,destination,btype);
            
             return new ResponseEntity<Integer>(routeinfoVc.getFare(),HttpStatus.OK);
        }
        return new ResponseEntity<Integer>(routeinfo.getFare(),HttpStatus.OK);
    }

    @PutMapping("/routeinfo/{id}")
    public ResponseEntity<Routeinfo> updateRouteinfo(@PathVariable("id") Integer id, @RequestBody Routeinfo routeinfo) {
        System.out.println("Updating Routeinfo " + id);

        Routeinfo currentRouteinfo = routeinfoService.viewOneRouteinfo(id);

        if (currentRouteinfo == null) {
            System.out.println("Routeinfo with id " + id + " not found");
            return new ResponseEntity<Routeinfo>(HttpStatus.NOT_FOUND);
        }

        currentRouteinfo.setDestination(routeinfo.getDestination());
        currentRouteinfo.setSource(routeinfo.getSource());
        currentRouteinfo.setFare(routeinfo.getFare());
        currentRouteinfo.setRouteid(routeinfo.getRouteid());
        currentRouteinfo.setBtype(routeinfo.getBtype());

        routeinfoService.updateRouteinfo(currentRouteinfo);
        return new ResponseEntity<Routeinfo>(currentRouteinfo, HttpStatus.OK);
    }

    @DeleteMapping("/routeinfo/{id}")
    public ResponseEntity<Routeinfo> deleteRouteinfo(@PathVariable("id") Integer id) {
        System.out.println("Fetching & Deleting Routeinfo with id " + id);

        Routeinfo routeinfo = routeinfoService.viewOneRouteinfo(id);
        if (routeinfo == null) {
            System.out.println("Unable to delete. Routeinfo with id " + id + " not found");
            return new ResponseEntity<Routeinfo>(HttpStatus.NOT_FOUND);
        }

        routeinfoService.deleteRouteinfo(id);
        return new ResponseEntity<Routeinfo>(HttpStatus.NO_CONTENT);
    }

}

