/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.myproject.eticket.controller;

import com.myproject.eticket.model.Businfo;
import com.myproject.eticket.service.BusinfoService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author User
 */
@RestController
@RequestMapping(value = "/api/v1")
public class BusinfoController {

    @Autowired
    private BusinfoService businfoService;

    @GetMapping("/businfo")
    public List<Businfo> getAllBusinfo() {
        return businfoService.viewBusinfo();
    }

    @PostMapping("/businfo")
    public Businfo createBusinfo(@RequestBody Businfo businfo) {
        return businfoService.insertBusinfo(businfo);
    }

    @GetMapping("/businfo/{id}")
    public ResponseEntity<Businfo> getBusinfo(@PathVariable("id") Integer id) {
        System.out.println("Fetching User with id " + id);
        Businfo businfo = businfoService.viewOneBusinfo(id);
        if (businfo == null) {
            System.out.println("Businfo with id " + id + " not found");
            return new ResponseEntity<Businfo>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Businfo>(businfo, HttpStatus.OK);
    }

    @PutMapping("/businfo/{id}")
    public ResponseEntity<Businfo> updateBusinfo(@PathVariable("id") Integer id, @RequestBody Businfo businfo) {
        System.out.println("Updating Businfo " + id);

        Businfo currentBusinfo = businfoService.viewOneBusinfo(id);

        if (currentBusinfo == null) {
            System.out.println("Businfo with id " + id + " not found");
            return new ResponseEntity<Businfo>(HttpStatus.NOT_FOUND);
        }

        currentBusinfo.setTimeid(businfo.getTimeid());
        currentBusinfo.setBusid(businfo.getBusid());
        currentBusinfo.setCompanyid(businfo.getCompanyid());
        currentBusinfo.setRouteid(businfo.getRouteid());
        currentBusinfo.setTypeid(businfo.getTypeid());

        businfoService.updateBusinfo(currentBusinfo);
        return new ResponseEntity<Businfo>(currentBusinfo, HttpStatus.OK);
    }

    @DeleteMapping("/businfo/{id}")
    public ResponseEntity<Businfo> deleteBusinfo(@PathVariable("id") Integer id) {
        System.out.println("Fetching & Deleting Businfo with id " + id);

        Businfo businfo = businfoService.viewOneBusinfo(id);
        if (businfo == null) {
            System.out.println("Unable to delete. Businfo with id " + id + " not found");
            return new ResponseEntity<Businfo>(HttpStatus.NOT_FOUND);
        }

        businfoService.deleteBusinfo(id);
        return new ResponseEntity<Businfo>(HttpStatus.NO_CONTENT);
    }

}
