/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.myproject.eticket.controller;

import com.myproject.eticket.model.Finalticket;
import com.myproject.eticket.service.FinalticketService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author User
 */
@RestController
@RequestMapping(value = "/api/v1")
public class FinalticketController {

    @Autowired
    private FinalticketService finalticketService;

    @GetMapping("/finalticket")
    public List<Finalticket> getAllFinalticket() {
        return finalticketService.viewFinalticket();
    }

    @PostMapping("/finalticket")
    
    public Finalticket createFinalticket(@RequestBody Finalticket finalticket) {
        return finalticketService.insertFinalticket(finalticket);
    }

    @GetMapping("/finalticket/{id}")
    public ResponseEntity<Finalticket> getFinalticket(@PathVariable("id") Integer id) {
        System.out.println("Fetching User with id " + id);
        Finalticket finalticket = finalticketService.viewOneFinalticket(id);
        if (finalticket == null) {
            System.out.println("Finalticket with id " + id + " not found");
            return new ResponseEntity<Finalticket>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Finalticket>(finalticket, HttpStatus.OK);
    }
    
      @GetMapping("/finalticket/ticketnumber/{ticketnumber}")
    public ResponseEntity<Finalticket> viewOneByTicketNum(@PathVariable("ticketnumber") Integer ticketnumber) {
        System.out.println("Fetching User with id " + ticketnumber);
        Finalticket finalticket = finalticketService.viewOneByTicketNum(ticketnumber);
        if (finalticket == null) {
            System.out.println("Finalticket with id " + ticketnumber + " not found");
            return new ResponseEntity<Finalticket>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Finalticket>(finalticket, HttpStatus.OK);
    }

    @PutMapping("/finalticket/{id}")
    public ResponseEntity<Finalticket> updateFinalticket(@PathVariable("id") Integer id, @RequestBody Finalticket finalticket) {
        System.out.println("Updating Finalticket " + id);

        Finalticket currentFinalticket = finalticketService.viewOneFinalticket(id);

        if (currentFinalticket == null) {
            System.out.println("Finalticket with id " + id + " not found");
            return new ResponseEntity<Finalticket>(HttpStatus.NOT_FOUND);
        }

        currentFinalticket.setTid(finalticket.getTid());
        currentFinalticket.setSource(finalticket.getSource());
        currentFinalticket.setDestination(finalticket.getDestination());
        currentFinalticket.setDdate(finalticket.getDdate());
        currentFinalticket.setDtime(finalticket.getDtime());
        currentFinalticket.setPname(finalticket.getPname());
        currentFinalticket.setPemail(finalticket.getPemail());
        currentFinalticket.setPphone(finalticket.getPphone());
        currentFinalticket.setSeatnumber(finalticket.getSeatnumber());
        currentFinalticket.setTicketnumber(finalticket.getTicketnumber());
        currentFinalticket.setTotalfare(finalticket.getTotalfare());
        currentFinalticket.setBustype(finalticket.getBustype());
        

        finalticketService.updateFinalticket(currentFinalticket);
        return new ResponseEntity<Finalticket>(currentFinalticket, HttpStatus.OK);
    }

    @DeleteMapping("/finalticket/{id}")
    public ResponseEntity<Finalticket> deleteFinalticket(@PathVariable("id") Integer id) {
        System.out.println("Fetching & Deleting Finalticket with id " + id);

        Finalticket finalticket = finalticketService.viewOneFinalticket(id);
        if (finalticket == null) {
            System.out.println("Unable to delete. Finalticket with id " + id + " not found");
            return new ResponseEntity<Finalticket>(HttpStatus.NOT_FOUND);
        }

        finalticketService.deleteFinalticket(id);
        return new ResponseEntity<Finalticket>(HttpStatus.NO_CONTENT);
    }

    
   
    
}
