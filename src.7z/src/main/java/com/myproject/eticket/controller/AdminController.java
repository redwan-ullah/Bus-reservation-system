/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.myproject.eticket.controller;

import com.myproject.eticket.model.Admin;
import com.myproject.eticket.service.AdminService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author User
 */
@RestController
@RequestMapping(value = "/api/v1")
public class AdminController {

    @Autowired
    private AdminService adminService;

    @GetMapping("/admin")
    public List<Admin> getAllAdmin() {
        return adminService.viewAdmin();
    }

    @PostMapping("/admin")
    public Admin createAdmin(@RequestBody Admin admin) {
        return adminService.insertAdmin(admin);
    }

    @GetMapping("/admin/{id}")
    public ResponseEntity<Admin> getAdmin(@PathVariable("id") Integer id) {
        System.out.println("Fetching User with id " + id);
        Admin admin = adminService.viewOneAdmin(id);
        if (admin == null) {
            System.out.println("Admin with id " + id + " not found");
            return new ResponseEntity<Admin>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Admin>(admin, HttpStatus.OK);
    }

        @GetMapping("/admin/auth/{aname}/{apass}")
    public ResponseEntity<String> getAdmin(@PathVariable("aname") String aname,@PathVariable("apass") String apass) {
        
        Admin admin = adminService.userName(aname);
        if (admin !=null) {
            Admin auth = adminService.userAuth(aname, apass);
            if (auth !=null){
            return new ResponseEntity<String>(aname, HttpStatus.OK);
            }
            else{return new ResponseEntity<String>("Wrong PassWord", HttpStatus.OK);}
            
        }
        else{return new ResponseEntity<String>("Admin Does't Exist", HttpStatus.OK);}
    }
    
    
    @PutMapping("/admin/{id}")
    public ResponseEntity<Admin> updateAdmin(@PathVariable("id") Integer id, @RequestBody Admin admin) {
        System.out.println("Updating Admin " + id);

        Admin currentAdmin = adminService.viewOneAdmin(id);

        if (currentAdmin == null) {
            System.out.println("Admin with id " + id + " not found");
            return new ResponseEntity<Admin>(HttpStatus.NOT_FOUND);
        }

        currentAdmin.setAdid(admin.getAdid());
        currentAdmin.setAdname(admin.getAdname());
        currentAdmin.setAdpassword(admin.getAdpassword());
        currentAdmin.setAdemail(admin.getAdemail());
       

        adminService.updateAdmin(currentAdmin);
        return new ResponseEntity<Admin>(currentAdmin, HttpStatus.OK);
    }

    @DeleteMapping("/admin/{id}")
    public ResponseEntity<Admin> deleteAdmin(@PathVariable("id") Integer id) {
        System.out.println("Fetching & Deleting Admin with id " + id);

        Admin admin = adminService.viewOneAdmin(id);
        if (admin == null) {
            System.out.println("Unable to delete. Admin with id " + id + " not found");
            return new ResponseEntity<Admin>(HttpStatus.NOT_FOUND);
        }

        adminService.deleteAdmin(id);
        return new ResponseEntity<Admin>(HttpStatus.NO_CONTENT);
    }

}
