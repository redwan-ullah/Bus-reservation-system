/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.myproject.eticket.controller;

import com.myproject.eticket.model.Ticketinfo;
import com.myproject.eticket.service.TicketinfoService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author User
 */
@RestController
@RequestMapping(value = "/api/v1")
public class TicketinfoController {

    @Autowired
    private TicketinfoService ticketinfoService;

    @GetMapping("/ticketinfo")
    public List<Ticketinfo> getAllTicketinfo() {
        return ticketinfoService.viewTicketinfo();
    }

    @PostMapping("/ticketinfo")
    public Ticketinfo createTicketinfo(@RequestBody Ticketinfo ticketinfo) {
        return ticketinfoService.insertTicketinfo(ticketinfo);
    }

    @GetMapping("/ticketinfo/{id}")
    public ResponseEntity<Ticketinfo> getTicketinfo(@PathVariable("id") Integer id) {
        System.out.println("Fetching User with id " + id);
        Ticketinfo ticketinfo = ticketinfoService.viewOneTicketinfo(id);
        if (ticketinfo == null) {
            System.out.println("Ticketinfo with id " + id + " not found");
            return new ResponseEntity<Ticketinfo>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Ticketinfo>(ticketinfo, HttpStatus.OK);
    }

    @PutMapping("/ticketinfo/{id}")
    public ResponseEntity<Ticketinfo> updateTicketinfo(@PathVariable("id") Integer id, @RequestBody Ticketinfo ticketinfo) {
        System.out.println("Updating Ticketinfo " + id);

        Ticketinfo currentTicketinfo = ticketinfoService.viewOneTicketinfo(id);

        if (currentTicketinfo == null) {
            System.out.println("Ticketinfo with id " + id + " not found");
            return new ResponseEntity<Ticketinfo>(HttpStatus.NOT_FOUND);
        }

        currentTicketinfo.setJourneydate(ticketinfo.getJourneydate());
        currentTicketinfo.setBusid(ticketinfo.getBusid());
        currentTicketinfo.setPassengerid(ticketinfo.getPassengerid());
        currentTicketinfo.setSeatno(ticketinfo.getSeatno());
        currentTicketinfo.setTicketid(ticketinfo.getTicketid());

        ticketinfoService.updateTicketinfo(currentTicketinfo);
        return new ResponseEntity<Ticketinfo>(currentTicketinfo, HttpStatus.OK);
    }

    @DeleteMapping("/ticketinfo/{id}")
    public ResponseEntity<Ticketinfo> deleteTicketinfo(@PathVariable("id") Integer id) {
        System.out.println("Fetching & Deleting Ticketinfo with id " + id);

        Ticketinfo ticketinfo = ticketinfoService.viewOneTicketinfo(id);
        if (ticketinfo == null) {
            System.out.println("Unable to delete. Ticketinfo with id " + id + " not found");
            return new ResponseEntity<Ticketinfo>(HttpStatus.NOT_FOUND);
        }

        ticketinfoService.deleteTicketinfo(id);
        return new ResponseEntity<Ticketinfo>(HttpStatus.NO_CONTENT);
    }

}
