/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.myproject.eticket.controller;

import com.myproject.eticket.model.Passengerinfo;
import com.myproject.eticket.service.PassengerinfoService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author User
 */
@RestController
@RequestMapping(value = "/api/v1")
public class PassengerinfoController {

    @Autowired
    private PassengerinfoService passengerinfoService;

    @GetMapping("/passengerinfo")
    public List<Passengerinfo> getAllPassengerinfo() {
        return passengerinfoService.viewPassengerinfo();
    }

    @PostMapping("/passengerinfo")
    public Passengerinfo createPassengerinfo(@RequestBody Passengerinfo passengerinfo) {
        return passengerinfoService.insertPassengerinfo(passengerinfo);
    }

    @GetMapping("/passengerinfo/{id}")
    public ResponseEntity<Passengerinfo> getPassengerinfo(@PathVariable("id") Integer id) {
        System.out.println("Fetching User with id " + id);
        Passengerinfo passengerinfo = passengerinfoService.viewOnePassengerinfo(id);
        if (passengerinfo == null) {
            System.out.println("Passengerinfo with id " + id + " not found");
            return new ResponseEntity<Passengerinfo>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Passengerinfo>(passengerinfo, HttpStatus.OK);
    }

    @PutMapping("/passengerinfo/{id}")
    public ResponseEntity<Passengerinfo> updatePassengerinfo(@PathVariable("id") Integer id, @RequestBody Passengerinfo passengerinfo) {
        System.out.println("Updating Passengerinfo " + id);

        Passengerinfo currentPassengerinfo = passengerinfoService.viewOnePassengerinfo(id);

        if (currentPassengerinfo == null) {
            System.out.println("Passengerinfo with id " + id + " not found");
            return new ResponseEntity<Passengerinfo>(HttpStatus.NOT_FOUND);
        }

        currentPassengerinfo.setPassengerid(passengerinfo.getPassengerid());
        currentPassengerinfo.setPassengeraddress(passengerinfo.getPassengeraddress());
        currentPassengerinfo.setPassengername(passengerinfo.getPassengername());
        currentPassengerinfo.setPassengerphone(passengerinfo.getPassengerphone());
        

        passengerinfoService.updatePassengerinfo(currentPassengerinfo);
        return new ResponseEntity<Passengerinfo>(currentPassengerinfo, HttpStatus.OK);
    }

    @DeleteMapping("/passengerinfo/{id}")
    public ResponseEntity<Passengerinfo> deletePassengerinfo(@PathVariable("id") Integer id) {
        System.out.println("Fetching & Deleting Passengerinfo with id " + id);

        Passengerinfo passengerinfo = passengerinfoService.viewOnePassengerinfo(id);
        if (passengerinfo == null) {
            System.out.println("Unable to delete. Passengerinfo with id " + id + " not found");
            return new ResponseEntity<Passengerinfo>(HttpStatus.NOT_FOUND);
        }

        passengerinfoService.deletePassengerinfo(id);
        return new ResponseEntity<Passengerinfo>(HttpStatus.NO_CONTENT);
    }

}
