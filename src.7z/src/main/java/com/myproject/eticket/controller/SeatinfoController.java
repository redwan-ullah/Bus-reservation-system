/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.myproject.eticket.controller;

import com.myproject.eticket.model.Seatinfo;
import com.myproject.eticket.service.SeatinfoService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author User
 */
@RestController
@RequestMapping(value = "/api/v1")
public class SeatinfoController {

    @Autowired
    private SeatinfoService seatinfoService;

    @GetMapping("/seatinfo")
    public List<Seatinfo> getAllSeatinfo() {
        return seatinfoService.viewSeatinfo();
    }

    @PostMapping("/seatinfo")
    public Seatinfo createSeatinfo(@RequestBody Seatinfo seatinfo) {
        return seatinfoService.insertSeatinfo(seatinfo);
    }

    @GetMapping("/seatinfo/{id}")
    public ResponseEntity<Seatinfo> getSeatinfo(@PathVariable("id") Integer id) {
        System.out.println("Fetching User with id " + id);
        Seatinfo seatinfo = seatinfoService.viewOneSeatinfo(id);
        if (seatinfo == null) {
            System.out.println("Seatinfo with id " + id + " not found");
            return new ResponseEntity<Seatinfo>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Seatinfo>(seatinfo, HttpStatus.OK);
    }

    @PutMapping("/seatinfo/{id}")
    public ResponseEntity<Seatinfo> updateSeatinfo(@PathVariable("id") Integer id, @RequestBody Seatinfo seatinfo) {
        System.out.println("Updating Seatinfo " + id);

        Seatinfo currentSeatinfo = seatinfoService.viewOneSeatinfo(id);

        if (currentSeatinfo == null) {
            System.out.println("Seatinfo with id " + id + " not found");
            return new ResponseEntity<Seatinfo>(HttpStatus.NOT_FOUND);
        }

        currentSeatinfo.setId(seatinfo.getId());
        currentSeatinfo.setBusid(seatinfo.getBusid());
        currentSeatinfo.setJourneydate(seatinfo.getJourneydate());
        

        seatinfoService.updateSeatinfo(currentSeatinfo);
        return new ResponseEntity<Seatinfo>(currentSeatinfo, HttpStatus.OK);
    }

    @DeleteMapping("/seatinfo/{id}")
    public ResponseEntity<Seatinfo> deleteSeatinfo(@PathVariable("id") Integer id) {
        System.out.println("Fetching & Deleting Seatinfo with id " + id);

        Seatinfo seatinfo = seatinfoService.viewOneSeatinfo(id);
        if (seatinfo == null) {
            System.out.println("Unable to delete. Seatinfo with id " + id + " not found");
            return new ResponseEntity<Seatinfo>(HttpStatus.NOT_FOUND);
        }

        seatinfoService.deleteSeatinfo(id);
        return new ResponseEntity<Seatinfo>(HttpStatus.NO_CONTENT);
    }

}
